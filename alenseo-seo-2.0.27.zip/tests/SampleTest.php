<?php

use PHPUnit\Framework\TestCase;

class SampleTest extends TestCase
{
    public function testExample()
    {
        $this->assertTrue(true);
    }
}
