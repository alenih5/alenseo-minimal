<?php
/**
 * Plugin Name: Alenseo SEO Minimal
 * Plugin URI: https://www.imponi.ch
 * Description: Ein schlankes SEO-Plugin mit Claude AI-Integration für WordPress
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Alen
 * Author URI: https://www.imponi.ch
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Company: Imponi Bern-Worb GmbH
 * Text Domain: alenseo
 * Domain Path: /languages
 */

// Direkter Zugriff verhindern
if (!defined('ABSPATH')) {
    exit;
}

define('ALENSEO_MINIMAL_DIR', plugin_dir_path(__FILE__));
define('ALENSEO_MINIMAL_URL', plugin_dir_url(__FILE__));
define('ALENSEO_MINIMAL_VERSION', '1.0.0');

require_once ALENSEO_MINIMAL_DIR . 'includes/minimal-admin.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/class-minimal-analysis.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/class-dashboard.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/class-claude-api.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/class-content-optimizer.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/alenseo-ajax-handlers.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/alenseo-claude-ajax.php';
require_once ALENSEO_MINIMAL_DIR . 'includes/alenseo-enhanced-ajax.php';

if (defined('WPB_VC_VERSION') || class_exists('WPBakeryVisualComposer')) {
    require_once ALENSEO_MINIMAL_DIR . 'includes/class-wpbakery-integration.php';
}

function alenseo_init() {
    try {
        new Alenseo_Minimal_Admin();
        new Alenseo_Dashboard();
        if (defined('WPB_VC_VERSION') || class_exists('WPBakeryVisualComposer')) {
            new Alenseo_WPBakery_Integration();
        }
    } catch (Exception $e) {
        error_log('Alenseo SEO Minimal - Initialisierungsfehler: ' . $e->getMessage());
    }
}
add_action('plugins_loaded', 'alenseo_init');

function alenseo_minimal_activate() {
    if (!get_option('alenseo_settings')) {
        $default_settings = array(
            'claude_api_key' => '',
            'claude_model' => 'claude-3-haiku-20240307',
            'post_types' => array('post', 'page'),
            'seo_elements' => array(
                'meta_title' => true,
                'meta_description' => true,
                'headings' => true,
                'content' => true
            )
        );
        update_option('alenseo_settings', $default_settings);
    }
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'alenseo_minimal_activate');

function alenseo_minimal_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'alenseo_minimal_deactivate');

function alenseo_minimal_add_action_links($links) {
    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=alenseo-minimal-settings') . '">' . __('Einstellungen', 'alenseo') . '</a>',
        '<a href="' . admin_url('admin.php?page=alenseo-optimizer') . '">' . __('SEO-Optimierung', 'alenseo') . '</a>'
    );
    return array_merge($plugin_links, $links);
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'alenseo_minimal_add_action_links');
