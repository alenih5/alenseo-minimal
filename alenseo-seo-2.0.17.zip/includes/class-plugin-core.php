<?php
/**
 * Hauptklasse für das Alenseo SEO Plugin
 *
 * Diese Klasse initialisiert alle Komponenten des Plugins und stellt sicher,
 * dass sie in der richtigen Reihenfolge geladen werden.
 *
 * @package Alenseo
 */

if (!defined('ABSPATH')) {
    exit;
}

class Alenseo_Plugin_Core {

    /**
     * Initialisiert das Plugin
     */
    public static function init() {
        // Klassen laden
        self::load_classes();

        // Hooks registrieren
        self::register_hooks();
    }

    /**
     * Lädt alle benötigten Klassen
     */
    private static function load_classes() {
        require_once ALENSEO_MINIMAL_DIR . 'includes/class-database.php';
        require_once ALENSEO_MINIMAL_DIR . 'includes/class-claude-api.php';
        require_once ALENSEO_MINIMAL_DIR . 'includes/class-enhanced-analysis.php';
        require_once ALENSEO_MINIMAL_DIR . 'includes/alenseo-ajax-handlers.php';
    }

    /**
     * Registriert alle notwendigen Hooks
     */
    private static function register_hooks() {
        // Datenbank-Setup bei Aktivierung
        register_activation_hook(ALENSEO_MINIMAL_FILE, array('Alenseo_Database', 'setup')); 

        // AJAX-Handler registrieren
        add_action('init', array('Alenseo_Claude_API', 'register_ajax_handlers'));
        add_action('init', array('Alenseo_Enhanced_Analysis', 'register_ajax_handlers'));
    }
}

// Plugin initialisieren
Alenseo_Plugin_Core::init();
