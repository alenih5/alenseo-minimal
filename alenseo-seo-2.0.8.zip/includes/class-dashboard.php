<?php
/**
 * Dashboard-Klasse für Alenseo
 * Diese Klasse enthält die Funktionalität für das SEO-Dashboard
 * und die Detailansicht
 * 
 * @link       https://www.imponi.ch
 * @since      1.0.0
 *
 * @package    Alenseo
 * @subpackage Alenseo/includes
 */

// Direkter Zugriff verhindern
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Die Dashboard-Klasse
 */
class Alenseo_Dashboard {

    /**
     * Enthält die Instanz der Datenbank-Klasse
     *
     * @since    1.0.0
     * @access   private
     * @var      Alenseo_Database    $db   Die Datenbank-Klasse
     */
    private $db;

    /**
     * Die ID des anzuzeigenden Artikels
     *
     * @since    1.0.0
     * @access   private
     * @var      int    $post_id    Die ID des anzuzeigenden Artikels
     */
    private $post_id;

    /**
     * Instanziierung der Klasse und Registrierung von WordPress-Hooks
     *
     * @since    1.0.0
     */
    public function __construct() {
        // Datenbank-Klasse instanziieren
        $this->db = new Alenseo_Database();

        // Menü im Admin-Bereich registrieren
        add_action('admin_menu', array($this, 'add_dashboard_menu'));

        // AJAX-Endpunkte für das Dashboard registrieren
        add_action('wp_ajax_alenseo_get_post_data', array($this, 'get_post_data'));
        add_action('wp_ajax_alenseo_get_score_history', array($this, 'get_score_history'));
        add_action('wp_ajax_alenseo_get_stats', array($this, 'get_stats'));

        // Scripts und Styles für das Dashboard laden
        add_action('admin_enqueue_scripts', array($this, 'enqueue_dashboard_assets'));
    }

    /**
     * Scripts und Styles für das Dashboard laden
     *
     * @since    1.0.0
     * @param    string    $hook    Der aktuelle Admin-Hook
     */
    public function enqueue_dashboard_assets($hook) {
        // Prüfen, ob wir auf der Dashboard-Seite sind
        if (strpos($hook, 'page_alenseo-dashboard') === false && $hook !== 'toplevel_page_alenseo-dashboard') {
            return;
        }

        // Visual Dashboard CSS
        $css_path = plugin_dir_path(dirname(__FILE__)) . 'assets/css/dashboard-visual.css';
        if (file_exists($css_path)) {
            wp_enqueue_style(
                'alenseo-dashboard-visual-css',
                plugin_dir_url(dirname(__FILE__)) . 'assets/css/dashboard-visual.css',
                array(),
                filemtime($css_path)
            );
        } else {
            error_log('CSS-Datei nicht gefunden: ' . $css_path);
        }

        // Visual Dashboard JS
        $js_path = plugin_dir_path(dirname(__FILE__)) . 'assets/js/dashboard-visual.js';
        if (file_exists($js_path)) {
            // Chart.js laden (falls benötigt)
            wp_enqueue_script(
                'chartjs',
                'https://cdn.jsdelivr.net/npm/chart.js',
                array(),
                '3.9.1',
                true
            );

            // Dashboard JS laden
            wp_enqueue_script(
                'alenseo-dashboard-visual-js',
                plugin_dir_url(dirname(__FILE__)) . 'assets/js/dashboard-visual.js',
                array('jquery', 'chartjs'),
                filemtime($js_path),
                true
            );

            // AJAX-URL und Nonce für JavaScript
            wp_localize_script('alenseo-dashboard-visual-js', 'alenseoData', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('alenseo_ajax_nonce'),
                'messages' => array(
                    'selectAction' => __('Bitte wähle eine Aktion aus.', 'alenseo'),
                    'selectContent' => __('Bitte wähle mindestens einen Inhalt aus.', 'alenseo'),
                    'analyzing' => __('Wird analysiert...', 'alenseo'),
                    'error' => __('Es ist ein Fehler aufgetreten.', 'alenseo'),
                    'allDone' => __('Alle Inhalte wurden verarbeitet.', 'alenseo')
                )
            ));
        } else {
            error_log('JS-Datei nicht gefunden: ' . $js_path);
        }
    }

    /**
     * Fügt den Dashboard-Menüpunkt im Admin-Bereich hinzu
     *
     * @since    1.0.0
     */
    public function add_dashboard_menu() {
        add_menu_page(
            'Alenseo SEO',
            'Alenseo SEO',
            'manage_options',
            'alenseo-dashboard',
            array($this, 'display_dashboard_page'),
            'dashicons-chart-area',
            100
        );

        // Untermenü für das Dashboard hinzufügen
        add_submenu_page(
            'alenseo-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'alenseo-dashboard',
            array($this, 'display_dashboard_page')
        );

        // Untermenü für die Einstellungen hinzufügen
        add_submenu_page(
            'alenseo-dashboard',
            'Einstellungen',
            'Einstellungen',
            'manage_options',
            'alenseo-settings',
            array($this, 'display_settings_page')
        );
    }

    /**
     * Zeigt die Hauptseite des Dashboards an
     *
     * @since    1.0.0
     */
    public function display_dashboard_page() {
        // URL-Parameter für die Detailansicht abfragen
        $this->post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
        
        if ($this->post_id > 0) {
            // Detailansicht für einen Artikel anzeigen
            $this->display_detail_page();
        } else {
            // Dashboard-Übersicht anzeigen
            $this->display_overview_page();
        }
    }

    /**
     * Zeigt die Übersichtsseite des Dashboards an
     *
     * @since    1.0.0
     */
    public function display_overview_page() {
        // Pfad zum Template
        $template_path = plugin_dir_path(dirname(__FILE__)) . 'templates/dashboard-page-visual.php';
        // Prüfen, ob die Template-Datei existiert
        if (file_exists($template_path)) {
            // Template einbinden
            include $template_path;
        } else {
            echo '<div class="error"><p>Template nicht gefunden: ' . esc_html($template_path) . '</p></div>';
        }
    }

    /**
     * Zeigt die Detailansicht für einen Artikel an
     *
     * @since    1.0.0
     */
    public function display_detail_page() {
        // Pfad zum Template
        $template_path = plugin_dir_path(dirname(__FILE__)) . 'templates/page-detail.php';
        
        // Artikel-Daten aus der Datenbank abrufen
        $post_data = $this->db->get_post_data($this->post_id);
        
        // Prüfen, ob die Template-Datei existiert
        if (file_exists($template_path)) {
            // Template einbinden
            include $template_path;
        } else {
            echo '<div class="error"><p>Template nicht gefunden: ' . esc_html($template_path) . '</p></div>';
        }
    }

    /**
     * Zeigt die Einstellungsseite an
     *
     * @since    1.0.0
     */
    public function display_settings_page() {
        // Pfad zum Template
        $template_path = plugin_dir_path(dirname(__FILE__)) . 'templates/settings-page.php';
        
        // Prüfen, ob die Template-Datei existiert
        if (file_exists($template_path)) {
            // Template einbinden
            include $template_path;
        } else {
            echo '<div class="error"><p>Template nicht gefunden: ' . esc_html($template_path) . '</p></div>';
        }
    }

    /**
     * AJAX-Callback für das Abrufen der Artikeldaten
     *
     * @since    1.0.0
     */
    public function get_post_data() {
        // Sicherheitscheck für AJAX-Anfrage
        check_ajax_referer('alenseo_nonce', 'security');

        // Eingabe validieren
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

        if ($post_id <= 0) {
            wp_send_json_error('Ungültige Artikel-ID');
            wp_die();
        }

        // Daten aus der Datenbank abrufen
        $post_data = $this->db->get_post_data($post_id);

        if ($post_data) {
            wp_send_json_success($post_data);
        } else {
            wp_send_json_error('Keine Daten für diesen Artikel gefunden');
        }

        wp_die();
    }

    /**
     * AJAX-Callback für das Abrufen des Score-Verlaufs
     *
     * @since    1.0.0
     */
    public function get_score_history() {
        // Sicherheitscheck für AJAX-Anfrage
        check_ajax_referer('alenseo_nonce', 'security');

        // Eingabe validieren
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

        if ($post_id <= 0) {
            wp_send_json_error('Ungültige Artikel-ID');
            wp_die();
        }

        // Daten aus der Datenbank abrufen
        $history_data = $this->db->get_score_history($post_id);

        if ($history_data) {
            wp_send_json_success($history_data);
        } else {
            wp_send_json_error('Keine Verlaufsdaten für diesen Artikel gefunden');
        }

        wp_die();
    }

    /**
     * AJAX-Callback für das Abrufen der Statistiken
     *
     * @since    1.0.0
     */
    public function get_stats() {
        // Sicherheitscheck für AJAX-Anfrage
        check_ajax_referer('alenseo_nonce', 'security');

        // Statistikdaten aus der Datenbank abrufen
        $stats = array(
            'total_posts' => $this->db->get_total_posts(),
            'analyzed_posts' => $this->db->get_analyzed_posts(),
            'average_score' => $this->db->get_average_score(),
            'recent_posts' => $this->db->get_recent_posts(5)
        );

        wp_send_json_success($stats);
        wp_die();
    }

    /**
     * Übersichtsdaten abrufen (für Dashboard-Header)
     * 
     * @return array Übersichtsdaten
     */
    public function get_overview_data() {
        // Verwende Transient für bessere Performance
        $cache_key = 'alenseo_overview_data';
        $cached_data = get_transient($cache_key);

        if ($cached_data !== false) {
            return $cached_data;
        }

        $data = array(
            'total_count' => $this->db->get_total_posts(),
            'optimized_count' => $this->db->get_analyzed_posts(),
            'needs_improvement_count' => $this->db->get_needs_improvement_posts(),
            'no_keyword_count' => $this->db->get_no_keyword_posts(),
            'average_score' => $this->db->get_average_score(),
            'keywords_count' => $this->db->get_total_keywords(),
            'top_keywords' => $this->db->get_top_keywords(),
            'items' => $this->get_all_posts()
        );

        // In Transient speichern (15 Minuten gültig)
        set_transient($cache_key, $data, 15 * MINUTE_IN_SECONDS);

        return $data;
    }

    /**
     * Aktualisiert den Score-Verlauf für einen Artikel
     *
     * @since    1.0.0
     * @param    int      $post_id    Die ID des Artikels
     * @param    int      $score      Der aktuelle Score
     */
    public function update_score_history($post_id, $score) {
        // Verlaufsdaten aus der Datenbank abrufen
        $history = $this->db->get_score_history($post_id);
        
        // Wenn keine Verlaufsdaten vorhanden sind, ein leeres Array erstellen
        if (empty($history)) {
            $history = array();
        }
        
        // Aktuelles Datum und Score hinzufügen
        $history[] = array(
            'date' => current_time('mysql'),
            'score' => $score
        );
        
        // Verlauf auf maximal 10 Einträge begrenzen
        if (count($history) > 10) {
            $history = array_slice($history, -10);
        }
        
        // Verlaufsdaten in der Datenbank speichern
        $this->db->update_score_history($post_id, $history);
    }

    /**
     * Gibt die neuesten analysierten Artikel zurück
     *
     * @since    1.0.0
     * @param    int      $count    Die Anzahl der zurückzugebenden Artikel
     * @return   array              Array mit Artikeldaten
     */
    public function get_recent_posts($count = 5) {
        return $this->db->get_recent_posts($count);
    }

    /**
     * Gibt die Anzahl aller Artikel zurück
     *
     * @since    1.0.0
     * @return   int      Anzahl der Artikel
     */
    public function get_total_posts() {
        return $this->db->get_total_posts();
    }

    /**
     * Gibt die Anzahl aller analysierten Artikel zurück
     *
     * @since    1.0.0
     * @return   int      Anzahl der analysierten Artikel
     */
    public function get_analyzed_posts() {
        return $this->db->get_analyzed_posts();
    }

    /**
     * Gibt den durchschnittlichen Score aller analysierten Artikel zurück
     *
     * @since    1.0.0
     * @return   float    Durchschnittlicher Score
     */
    public function get_average_score() {
        return $this->db->get_average_score();
    }

    /**
     * Alle Beiträge und Seiten abrufen
     * 
     * @param array $args Zusätzliche Query-Parameter
     * @return array Array mit SEO-Daten pro Post
     */
    public function get_all_posts($args = array()) {
        // Standard-Abfrageparameter
        $default_args = array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'orderby' => 'date',
            'order' => 'DESC'
        );
        $settings = get_option('alenseo_settings', array());
        if (isset($settings['post_types']) && is_array($settings['post_types'])) {
            $default_args['post_type'] = $settings['post_types'];
        }
        $query_args = wp_parse_args($args, $default_args);
        if (isset($args['status'])) {
            $status = $args['status'];
            unset($query_args['status']);
            $query_args['meta_query'] = array();
            switch ($status) {
                case 'good':
                    $query_args['meta_query'][] = array(
                        'key' => '_alenseo_seo_score',
                        'value' => 80,
                        'compare' => '>=',
                        'type' => 'NUMERIC'
                    );
                    break;
                case 'needs_improvement':
                    $query_args['meta_query'][] = array(
                        'key' => '_alenseo_seo_score',
                        'value' => array(50, 79),
                        'compare' => 'BETWEEN',
                        'type' => 'NUMERIC'
                    );
                    break;
                case 'poor':
                    $query_args['meta_query'][] = array(
                        'key' => '_alenseo_seo_score',
                        'value' => 50,
                        'compare' => '<',
                        'type' => 'NUMERIC'
                    );
                    break;
                case 'no_keyword':
                    $query_args['meta_query'][] = array(
                        'relation' => 'OR',
                        array(
                            'key' => '_alenseo_keyword',
                            'value' => '',
                            'compare' => '='
                        ),
                        array(
                            'key' => '_alenseo_keyword',
                            'compare' => 'NOT EXISTS'
                        )
                    );
                    break;
            }
        }
        $query = new WP_Query($query_args);
        $posts = $query->posts;
        $result = array();
        foreach ($posts as $post) {
            $post_obj = new stdClass();
            $post_obj->ID = $post->ID;
            $post_obj->post_title = $post->post_title;
            $post_obj->post_type = $post->post_type;
            $seo_data = $this->get_post_seo_data($post->ID);
            $post_obj->seo_score = $seo_data['score'];
            $post_obj->seo_status = $seo_data['status'];
            $post_obj->seo_status_label = $seo_data['status_text'];
            $post_obj->keyword = $seo_data['keyword'];
            $post_obj->meta_description = $seo_data['meta_description'];
            $post_obj->permalink = get_permalink($post->ID);
            $result[] = $post_obj;
        }
        return $result;
    }

    /**
     * SEO-Score und Status für einen Beitrag abrufen
     * 
     * @param int $post_id Die Post-ID
     * @return array Array mit Score und Status
     */
    public function get_post_seo_data($post_id) {
        global $alenseo_database;
        $data = array(
            'score' => 0,
            'status' => 'unknown',
            'status_text' => __('Nicht analysiert', 'alenseo'),
            'keyword' => get_post_meta($post_id, '_alenseo_keyword', true),
            'meta_description' => ''
        );
        $seo_score = 0;
        $seo_status = 'unknown';
        if (isset($alenseo_database) && method_exists($alenseo_database, 'get_seo_score')) {
            $seo_data = $alenseo_database->get_seo_score($post_id);
            if ($seo_data && isset($seo_data['score'])) {
                $seo_score = $seo_data['score'];
                if ($seo_score >= 80) {
                    $seo_status = 'good';
                } elseif ($seo_score >= 50) {
                    $seo_status = 'ok';
                } else {
                    $seo_status = 'poor';
                }
                update_post_meta($post_id, '_alenseo_seo_score', $seo_score);
                update_post_meta($post_id, '_alenseo_seo_status', $seo_status);
            }
        } else {
            $seo_score = get_post_meta($post_id, '_alenseo_seo_score', true);
            $seo_status = get_post_meta($post_id, '_alenseo_seo_status', true);
        }
        if ($seo_score !== '') {
            $data['score'] = intval($seo_score);
            if ($data['score'] >= 80) {
                $data['status'] = 'good';
                $data['status_text'] = __('Gut optimiert', 'alenseo');
            } elseif ($data['score'] >= 50) {
                $data['status'] = 'ok';
                $data['status_text'] = __('Teilweise optimiert', 'alenseo');
            } else {
                $data['status'] = 'poor';
                $data['status_text'] = __('Optimierung nötig', 'alenseo');
            }
        }
        $meta_description = get_post_meta($post_id, '_alenseo_meta_description', true);
        if (empty($meta_description)) {
            $meta_description = get_post_meta($post_id, '_yoast_wpseo_metadesc', true);
            if (empty($meta_description)) {
                $meta_description = get_post_meta($post_id, '_aioseo_description', true);
            }
            if (empty($meta_description)) {
                $meta_description = get_post_meta($post_id, '_aioseop_description', true);
            }
            if (empty($meta_description)) {
                $meta_description = get_post_meta($post_id, 'rank_math_description', true);
            }
            if (empty($meta_description)) {
                $meta_description = get_post_meta($post_id, '_seopress_titles_desc', true);
            }
            if (empty($meta_description)) {
                $meta_description = get_post_meta($post_id, 'vc_description', true);
            }
        }
        $data['meta_description'] = $meta_description;
        return $data;
    }
}